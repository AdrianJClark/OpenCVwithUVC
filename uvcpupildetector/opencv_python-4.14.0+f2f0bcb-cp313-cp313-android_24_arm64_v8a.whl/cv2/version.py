opencv_version = "4.14.0+f2f0bcb"
contrib = False
headless = False
rolling = False
ci_build = False