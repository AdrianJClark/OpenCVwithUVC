import os

BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'sdk/native/libs/')
] + BINARIES_PATHS
